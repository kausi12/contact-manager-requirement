
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
import re

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///contacts.db'
app.config['SECRET_KEY'] = 'secret'
db = SQLAlchemy(app)

class Contact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(200), unique=True, nullable=False)
    phone = db.Column(db.String(25), nullable=False)

def valid_email(email):
    return re.match(r"[^@]+@[^@]+\.[^@]+", email)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        phone = request.form["phone"]

        if not name or not email or not phone:
            flash("All fields are required")
        elif not valid_email(email):
            flash("Invalid email format")
        elif Contact.query.filter_by(email=email).first():
            flash("Email already exists")
        else:
            db.session.add(Contact(name=name, email=email, phone=phone))
            db.session.commit()
            return redirect(url_for("index"))

    return render_template("index.html", contacts=Contact.query.all())

@app.route("/delete/<int:id>")
def delete(id):
    c = Contact.query.get_or_404(id)
    db.session.delete(c)
    db.session.commit()
    return redirect(url_for("index"))

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
